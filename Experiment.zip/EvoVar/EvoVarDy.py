#! /usr/bin/env python
from psychopy import core, visual,event,sound
from psychopy import prefs
prefs.general['audioLib'] = ['pygame']
import time, random
import numpy as np
#import xlwt
#from xlutils.copy import copy
#from xlrd import open_workbook
from socket import *
import glob
from operator import mul
from PIL import Image
import pickle
import itertools
from collections import OrderedDict
from itertools import izip_longest
import csv
import ast
import os.path
import sys


########################################################################################################################
###################################################### PAIRING #########################################################
########################################################################################################################


#sends a message to other machine
def send_a_message(message,socket):
    socket.send(message)

#listens for message from other machine, whether blocked or unblocked
#only need unblocked if both machines need to send messages at the same time, or listen for more than 1 message
def receive_a_message(blocked,socket):
    data=socket.recv(1024)
    return data

def waiting_connection(myWin):
    openscreen = visual.TextStim(myWin, text="Waiting for connection...", units='deg', color='black')
    openscreen.draw()
    myWin.flip()

def wait_text(myWin):
    waittext = visual.TextStim(myWin, text="Waiting for partner...", units='deg', color='black')
    waittext.draw()
    myWin.flip()

def wait_feedback(myWin):
    waittext = visual.TextStim(myWin, text="Waiting for feedback...", units='deg', color='black')
    waittext.draw()
    myWin.flip()

def feedback_screen(myWin,feedback,path):
    if feedback=='correct': fondo='PaleGreen'
    elif feedback=='wrong':fondo='tomato'
    background= visual.Rect(myWin, units='norm', width=4, height=6, fillColor=fondo)
    #waittext = visual.TextStim(myWin, text=feedback, units='deg', color='black')
    background.draw()
    #waittext.draw()
    myWin.flip()
    myWin.setMouseVisible(False)
    playSound('soundEffects/%s'%feedback,path)
    myWin.setMouseVisible(True)
    if feedback=='wrong':
        core.wait(0.7)

########################################################################################################################
######################################################MEANINGS&SIGNALS#########################################################
########################################################################################################################


def get_meanings():
	dimensions=[('jelpa','mokte'),('plain','blue'),('one','two')]
	list_meanings=list(itertools.product(*dimensions))
	return list_meanings

def get_signals(meanings,sentences):
	return OrderedDict(zip(meanings,sentences))
    
def dict_stims(path):
    list_meanings=get_meanings()
    list_jpg=[path+'stims/'+''.join(i)+'.jpg' for i in list_meanings]
    dict_stims=OrderedDict(zip(list_meanings,list_jpg))
    return dict_stims

def get_dict_grammaticality(condition):
    meanings=[i for i in get_meanings() if ('plain','one')!= i[1:]]
    if condition=='m': signals=[['jelpa nefri', 'jelpa nezno', 'nezno jelpa'], ['jelpa kogla', 'jelpa kospu', 'kospu jelpa'], ['jelpa kogla nefri', 'jelpa kogla nezno', 'jelpa kospu nefri', 'jelpa kospu nezno', 'jelpa nefri kogla', 'jelpa kodri nezno'], ['mokte nefri', 'mokte nezno', 'nezno mokte'], ['mokte kogla', 'mokte kospu', 'kospu mokte'], ['mokte kogla nefri', 'mokte kogla nezno', 'mokte kospu nefri', 'mokte kospu nezno', 'mokte nefri kospu', 'mokte kogla netsu']]
    if condition=='s': signals=[['jelpa nefri', 'nefri jelpa', 'nezno jelpa'], ['jelpa kogla', 'kogla jelpa', 'kospu jelpa'], ['jelpa kogla nefri', 'nefri jelpa kogla', 'kogla jelpa nefri', 'nefri kogla jelpa', 'jelpa nefri kogla', 'nefri kospu jelpa'], ['mokte nefri', 'nefri mokte', 'nezno mokte'], ['mokte kogla', 'kogla mokte', 'kospu mokte'], ['mokte kogla nefri', 'nefri mokte kogla', 'kogla mokte nefri', 'nefri kogla mokte','kogla nefri mokte', 'mokte kogla nezno']]
    if condition=='ss': signals=[['jelpa nefri', 'nefri jelpa', 'nezno jelpa'], ['jelpa kogla', 'kogla jelpa', 'kospu jelpa'], ['jelpa kogla nefri', 'nefri jelpa kogla', 'kogla jelpa nefri', 'nefri kogla jelpa', 'jelpa nefri kogla', 'jelpa nefri kospu'], ['mokte nefri', 'nefri mokte', 'nezno mokte'], ['mokte kogla', 'kogla mokte', 'kospu mokte'], ['mokte kogla nefri', 'nefri mokte kogla', 'kogla mokte nefri', 'mokte nefri kogla','kogla nefri mokte', 'mokte kogla nezno']]
    dict_gram=get_signals(meanings,signals)
    return dict_gram  

def get_meanings_discrimination():
	list_meanings=get_meanings()
	return list_meanings+[('blifona','plain','one'), ('flarma','plain','one')]

def dict_stims_discrimination(path):
    list_meanings=get_meanings_discrimination()
    list_jpg=[path+'stims/'+''.join(i)+'.jpg' for i in list_meanings]
    dict_stims=dict(zip(list_meanings,list_jpg))
    return dict_stims

def hamming(m1, m2):
    dist=0
    for i in range(min(len(m1),len(m2))):
        if m1[i]!=m2[i]:
            dist+=1
    dist+=abs(len(m1)-len(m2))
    return dist

def choose_foils(meaning,diff_types):#diff_types==1 if only one dimension is allowed to differentiate (so only int he Block1) and diff_types==3 elsewhere
	list_candidates_final=[]
	for diff_type in range(diff_types):
		meaning_candidates=get_meanings_discrimination()
		list_candidates=[i for i in meaning_candidates if hamming(i,meaning)==1]
		list_candidates_final.append([i for i in list_candidates if meaning[diff_type]!=i[diff_type]])
	if diff_types!=1:
		new_list=[]
		for diff_type in range(diff_types):
			new_list.append(random.choice(list_candidates_final[diff_type]))
		list_candidates_final=[new_list]
	return list_candidates_final[0]

def choose_foils_proper(meaning,diff_type):#0 only in the training of labels ('plain', 'one') that is, otherwise diff_types== 1, you can also specify 'adj' or ;'noun' for block2 training (2 words)
	meaning_candidates=get_meanings_discrimination()
	if diff_type == 1:
		diff_type=random.choice(['adj','num','noun'])
	if diff_type==0:
		list_candidates_final=[i for i in meaning_candidates if hamming(i,meaning)==1 and i[1:]==meaning[1:]]
	if diff_type=='adj':
		reduced_list_adj=[i for i in meaning_candidates if i[0] not in ['blifona','flarma']]
		candidate1a=[i for i in reduced_list_adj if hamming(i,meaning)==1 and i[1:]==meaning[1:]]
		candidate1b=[i for i in reduced_list_adj if hamming(i,meaning)==1 and list(np.array(i)[[0,2]])==list(np.array(meaning)[[0,2]])]
		candidate2=[i for i in reduced_list_adj if hamming(i,meaning)==2 and i[2]==meaning[2]]
		list_candidates_final=candidate1a+candidate1b+candidate2
	if diff_type=='num':
		reduced_list_adj=[i for i in meaning_candidates if i[0] not in ['blifona','flarma']]
		candidate1a=[i for i in reduced_list_adj if hamming(i,meaning)==1 and i[1:]==meaning[1:]]
		candidate1b=[i for i in reduced_list_adj if hamming(i,meaning)==1 and i[:2]==meaning[:2]]
		candidate2=[i for i in reduced_list_adj if hamming(i,meaning)==2 and i[1]==meaning[1]]
		list_candidates_final=candidate1a+candidate1b+candidate2
	if diff_type=='noun':
		reduced_list=[i for i in meaning_candidates if i[0] not in ['blifona','flarma'] and i!=meaning]
		list_candidates_final=[i for i in reduced_list if i[0]==meaning[0]]
	return list_candidates_final
########################################################################################################################
####################################################SPELL CHECK########################################################
########################################################################################################################

def shuffle(l):
    return random.sample(l,len(l))
    
def levenshtein(seq1, seq2):
    oneago = None
    thisrow = range(1, len(seq2) + 1) + [0]
    for x in xrange(len(seq1)):
        twoago, oneago, thisrow = oneago, thisrow, [0] * len(seq2) + [x + 1]
        for y in xrange(len(seq2)):
            delcost = oneago[y] + 1
            addcost = thisrow[y - 1] + 1
            subcost = oneago[y - 1] + (seq1[x] != seq2[y])
            thisrow[y] = min(delcost, addcost, subcost)
    return thisrow[len(seq2) - 1]

def dl(s1, s2):
	d = {}
	lenstr1 = len(s1)
	lenstr2 = len(s2)
	for i in xrange(-1,lenstr1+1):
	    d[(i,-1)] = i+1
	for j in xrange(-1,lenstr2+1):
	    d[(-1,j)] = j+1
	for i in xrange(lenstr1):
	    for j in xrange(lenstr2):
	        if s1[i] == s2[j]:
	            cost = 0
	        else:
	            cost = 1
	        d[(i,j)] = min(
	                       d[(i-1,j)] + 1, # deletion
	                       d[(i,j-1)] + 1, # insertion
	                       d[(i-1,j-1)] + cost, # substitution
	                      )
	        if i and j and s1[i]==s2[j-1] and s1[i-1] == s2[j]:
	            d[(i,j)] = min (d[(i,j)], d[i-2,j-2] + cost) # transposition
	return d[lenstr1-1,lenstr2-1]

def spellcheckWord(word,possibleWords):
    #print word,possibleWords
    possibleWords = shuffle(possibleWords) #shuffles so that the match is randomly selected among the closest
    d = np.inf # set to arbitrarily large number
    bestMatch = None
    for possibleWord in possibleWords:
        d_new = dl(word,possibleWord); # compute dl or levenshtein edit distance
        # if closer than previous try, store replacement word in position i of output list
        if d_new < d :
            bestMatch = possibleWord
            d = d_new
    return bestMatch

def spellcheckWord2(word,possibleWords):
    #print word,possibleWords
    possibleWords = shuffle(possibleWords) #shuffles so that the match is randomly selected among the closest
    d = np.inf # set to arbitrarily large number
    bestMatch = None
    for possibleWord in possibleWords:
        d_new = dl(word,possibleWord); # compute levenshtein edit distance
        # if closer than previous try, store replacement word in position i of output list
        if d_new < d :
            bestMatch = possibleWord
            d = d_new
        if d_new==d:
        	if word[0]!=bestMatch[0] and word[0]==possibleWord[0]:
        		bestMatch = possibleWord
            	d = d_new
    return bestMatch

def spellcheckWords(str,condition):
    str = str.lower() # check to make sure things are lower case
    input = str.split(); # split into array of words - not specifying a seperator means that multipe whitespace is treated as one, empty whitespace is ignored
    if condition=='m': possibleWords = ['nezno','nefri','kogla','kospu','mokte','jelpa']
    else: possibleWords = ['nefri','kogla','mokte','jelpa']
    correctedWords = [spellcheckWord2(word,possibleWords) for word in input]#or plain spellcheckWord () for not weighted correction
    output = ' '.join(correctedWords)# turn back into a string
    return output

########################################################################################################################
######################################################SOUND & CO###########################################################
########################################################################################################################

def setSound(theSound,path):
    if ' ' in theSound:
        theSound=''.join(theSound.split())
    instr = sound.SoundPygame(path+'sounds/'+theSound+'.wav')
    dur = instr.getDuration(); instr.setVolume(1.0);
    return (instr, dur)
    
def playSound(theSound,path):
    (instr, dur) = setSound(theSound,path)
    instr.play(); 
#    if Interruptible:
#        event.waitKeys(dur,'space')
#        instr.stop()
#    else:
    core.wait(dur)

def draw_fixation(myWin):
   fixation = visual.TextStim(myWin, color='gray', units='norm', pos=[0,0], text='') 
   fixation.draw()
   myWin.flip()
   core.wait(0.1)

########################################################################################################################
######################################################TRAINING#######################################################
########################################################################################################################

def discrimination_trial(myWin,condition,chain,ID,phase,signal,meaning,diff_type,dict_stims,weird,path,myRole):
    texty=visual.TextStim(myWin, color='black', units='norm',pos=[0,0.1],text=signal)
    foils=choose_foils_proper(meaning,diff_type)
    foils=random.sample(foils,len(foils))
    key_pos=[['f'],['j'],['v'],['n']]
    pos_alt=[[-0.6,0.6],[0.6,0.6],[-0.6,-0.4],[0.6,-0.4]]
    position_meaning=random.choice(range(4))
    pos_meaning=pos_alt[position_meaning]
    pos_alt.remove(pos_alt[position_meaning])
    right_key=key_pos[position_meaning]
    key_pos.remove(right_key)
    box0= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_meaning, lineColor='DimGray')
    box1= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[0], lineColor='DimGray')
    box2= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[1], lineColor='DimGray') 
    box3= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[2], lineColor='DimGray')  
    left_top_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_F.png', units='norm', size=[0.15,0.15],pos=[-0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
    right_top_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_J.png', units='norm', size=[0.15,0.15],pos=[0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
    left_bottom_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_V.png', units='norm', size=[0.15,0.15],pos=[-0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
    right_bottom_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_N.png', units='norm', size=[0.15,0.15],pos=[0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
    image1= visual.ImageStim(myWin, weird[meaning], units='norm', size=[0.6, 0.6], pos=pos_meaning,flipHoriz=False,flipVert=False,autoLog=True)
    image2= visual.ImageStim(myWin, weird[foils[0]], units='norm', size=[0.6,0.6], pos=pos_alt[0], flipHoriz=False,flipVert=False,autoLog=True)
    image3= visual.ImageStim(myWin, weird[foils[1]], units='norm', size=[0.6,0.6], pos=pos_alt[1], flipHoriz=False,flipVert=False,autoLog=True)
    image4= visual.ImageStim(myWin, weird[foils[2]], units='norm', size=[0.6,0.6], pos=pos_alt[2], flipHoriz=False,flipVert=False,autoLog=True)
    play_sound=0
    while True:
        play_sound+=1
        draw_fixation(myWin)
        box0.setAutoDraw(True)
        box1.setAutoDraw(True)
        box2.setAutoDraw(True)
        box3.setAutoDraw(True)
        left_top_key.setAutoDraw(True)
        left_bottom_key.setAutoDraw(True)
        right_top_key.setAutoDraw(True)
        right_bottom_key.setAutoDraw(True)
        image1.setAutoDraw(True)
        image2.setAutoDraw(True)
        image3.setAutoDraw(True)
        image4.setAutoDraw(True)
        myWin.flip()
        core.wait(1)
        texty.setAutoDraw(True)
        myWin.flip()
        if play_sound==1:
            myWin.setMouseVisible(False)
            playSound(signal,path)
            myWin.setMouseVisible(True)
            stopwatch = core.Clock()
            stopwatch.reset()
        if event.getKeys(right_key):
            rt=stopwatch.getTime()
            write_outputCSV(path,condition,chain,ID,phase,meaning,signal,rt, 'correct','NA','NA','NA','NA',myRole)
            box0.setAutoDraw(False)
            box1.setAutoDraw(False)
            box2.setAutoDraw(False)
            box3.setAutoDraw(False)
            left_top_key.setAutoDraw(False)
            left_bottom_key.setAutoDraw(False)
            right_top_key.setAutoDraw(False)
            right_bottom_key.setAutoDraw(False)
            image2.setAutoDraw(False)
            image3.setAutoDraw(False)
            image4.setAutoDraw(False)
            myWin.flip()
            myWin.setMouseVisible(False)
            playSound('soundEffects/correct',path)
            myWin.setMouseVisible(True)
            break
        else:
            keys=event.getKeys()
            if 'escape' in keys :
                myWin.close()
                core.quit()
            elif any(key in list(itertools.chain(*key_pos)) for key in keys):
                if list(keys[-1]) not in key_pos: keys=random.choice(key_pos)
                rt=stopwatch.getTime()
                write_outputCSV(path,condition,chain,ID,phase,meaning,signal,rt, foils[key_pos.index(list(keys[-1]))],'NA','NA','NA','NA',myRole)
                box0.setAutoDraw(False)
                box1.setAutoDraw(False)
                box2.setAutoDraw(False)
                box3.setAutoDraw(False)
                left_top_key.setAutoDraw(False)
                left_bottom_key.setAutoDraw(False)
                right_top_key.setAutoDraw(False)
                right_bottom_key.setAutoDraw(False)
                image2.setAutoDraw(False)
                image3.setAutoDraw(False)
                image4.setAutoDraw(False)
                myWin.flip()
                myWin.setMouseVisible(False)
                playSound('soundEffects/wrong',path)
                core.wait(0.5)
                playSound(signal,path)
                core.wait(0.5)
                myWin.setMouseVisible(True)
                break
    event.clearEvents()
    image1.setAutoDraw(False)
    texty.setAutoDraw(False)
    
def discrimination_trialDy(myWin,condition,chain,ID,phase,signal,meaning,diff_type,dict_stims,weird,path,socket,myRole):
    texty=visual.TextStim(myWin, color='black', units='norm',pos=[0,0.1],text=signal)
    foils=choose_foils_proper(meaning,diff_type)
    foils=random.sample(foils,len(foils))
    key_pos=[['f'],['j'],['v'],['n']]
    pos_alt=[[-0.6,0.6],[0.6,0.6],[-0.6,-0.4],[0.6,-0.4]]
    position_meaning=random.choice(range(4))
    pos_meaning=pos_alt[position_meaning]
    pos_alt.remove(pos_alt[position_meaning])
    right_key=key_pos[position_meaning]
    key_pos.remove(right_key)
    box0= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_meaning, lineColor='DimGray')
    box1= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[0], lineColor='DimGray')
    box2= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[1], lineColor='DimGray') 
    box3= visual.Rect(myWin, units='norm', lineWidth=4.5,width=0.65, height=0.65, pos=pos_alt[2], lineColor='DimGray')  
    left_top_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_F.png', units='norm', size=[0.15,0.15],pos=[-0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
    right_top_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_J.png', units='norm', size=[0.15,0.15],pos=[0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
    left_bottom_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_V.png', units='norm', size=[0.15,0.15],pos=[-0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
    right_bottom_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_N.png', units='norm', size=[0.15,0.15],pos=[0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
    image1= visual.ImageStim(myWin, weird[meaning], units='norm', size=[0.6, 0.6], pos=pos_meaning,flipHoriz=False,flipVert=False,autoLog=True)
    image2= visual.ImageStim(myWin, weird[foils[0]], units='norm', size=[0.6,0.6], pos=pos_alt[0], flipHoriz=False,flipVert=False,autoLog=True)
    image3= visual.ImageStim(myWin, weird[foils[1]], units='norm', size=[0.6,0.6], pos=pos_alt[1], flipHoriz=False,flipVert=False,autoLog=True)
    image4= visual.ImageStim(myWin, weird[foils[2]], units='norm', size=[0.6,0.6], pos=pos_alt[2], flipHoriz=False,flipVert=False,autoLog=True)
    play_sound=0
    while True:
        play_sound+=1
        draw_fixation(myWin)
        box0.setAutoDraw(True)
        box1.setAutoDraw(True)
        box2.setAutoDraw(True)
        box3.setAutoDraw(True)
        left_top_key.setAutoDraw(True)
        left_bottom_key.setAutoDraw(True)
        right_top_key.setAutoDraw(True)
        right_bottom_key.setAutoDraw(True)
        image1.setAutoDraw(True)
        image2.setAutoDraw(True)
        image3.setAutoDraw(True)
        image4.setAutoDraw(True)
        texty.setAutoDraw(True)
        myWin.flip()
        if play_sound==1:
            stopwatch = core.Clock()
            stopwatch.reset()
        if event.getKeys(right_key):
            rt=stopwatch.getTime()
            write_outputCSV(path,condition,chain,ID,phase,meaning,signal,rt, 'correct','NA','NA','NA','NA',myRole)
            send_a_message('correct',socket)
            box0.setAutoDraw(False)
            box1.setAutoDraw(False)
            box2.setAutoDraw(False)
            box3.setAutoDraw(False)
            left_top_key.setAutoDraw(False)
            left_bottom_key.setAutoDraw(False)
            right_top_key.setAutoDraw(False)
            right_bottom_key.setAutoDraw(False)
            image1.setAutoDraw(False)
            image2.setAutoDraw(False)
            image3.setAutoDraw(False)
            image4.setAutoDraw(False)
            texty.setAutoDraw(False)
            myWin.flip()
            feedback_screen(myWin,'correct',path)
            break
        else:
            keys=event.getKeys()
            if 'escape' in keys :
                myWin.close()
                core.quit()
            elif any(key in list(itertools.chain(*key_pos)) for key in keys):
                if list(keys[-1]) not in key_pos: keys=random.choice(key_pos)
                rt=stopwatch.getTime()
                write_outputCSV(path,condition,chain,ID,phase,meaning,signal,rt, foils[key_pos.index(list(keys[-1]))],'NA','NA','NA','NA',myRole)
                send_a_message('wrong',socket)
                box0.setAutoDraw(False)
                box1.setAutoDraw(False)
                box2.setAutoDraw(False)
                box3.setAutoDraw(False)
                left_top_key.setAutoDraw(False)
                left_bottom_key.setAutoDraw(False)
                right_top_key.setAutoDraw(False)
                right_bottom_key.setAutoDraw(False)
                image1.setAutoDraw(False)
                image2.setAutoDraw(False)
                image3.setAutoDraw(False)
                image4.setAutoDraw(False)
                texty.setAutoDraw(False)
                myWin.flip()
                feedback_screen(myWin,'wrong',path)
                break
    event.clearEvents()
    
    

def double_dict(dict_meanings):
    for i in dict_meanings:
        if i not in [('mokte','plain','one'),('jelpa','plain','one')]:
            dict_meanings[i]=dict_meanings[i]*2
    return dict_meanings

def double_dict2(dict_meanings):
    for i in dict_meanings:
        if i in [('mokte','blue','two'),('jelpa','blue','two')]:
            dict_meanings[i]=dict_meanings[i]*2
    return dict_meanings
    
def trainingDy(myWin, condition,chain,ID,dict_meanings1, dict_meanings2,dict_stims,weird,path,socket,role,myRole):
    count_minitest_intro=0
    count_fullon_training=0
    #block one, only N, block2 two words adj or num, and block 3 and 4 etc, all
    block_1w=[('jelpa','plain','one'),]*5+[('mokte','plain','one'),]*5
    block_2w=[('jelpa','blue','one'),]*10+[('mokte','blue','one'),]*10+[('jelpa','plain','two'),]*10+[('mokte','plain','two'),]*10
    block_all_1=[('jelpa','blue','one'),]*3+[('mokte','blue','one'),]*2+[('jelpa','plain','two'),]*2+[('mokte','plain','two'),]*3+[('jelpa','blue','two'),]*7+[('mokte','blue','two'),]*8
    block_all_2=[('jelpa','blue','one'),]*2+[('mokte','blue','one'),]*3+[('jelpa','plain','two'),]*3+[('mokte','plain','two'),]*2+[('jelpa','blue','two'),]*8+[('mokte','blue','two'),]*7
    block_all_3=[('jelpa','blue','one'),]*3+[('mokte','blue','one'),]*2+[('jelpa','plain','two'),]*2+[('mokte','plain','two'),]*3+[('jelpa','blue','two'),]*7+[('mokte','blue','two'),]*8
    block_all_4=[('jelpa','blue','one'),]*2+[('mokte','blue','one'),]*3+[('jelpa','plain','two'),]*3+[('mokte','plain','two'),]*2+[('jelpa','blue','two'),]*8+[('mokte','blue','two'),]*7
    for i in range(0):        
        meaning=random.choice(block_1w)
        block_1w.remove(meaning)
        signal=random.choice(dict_meanings1[meaning])
        dict_meanings1[meaning].remove(signal)
        #print dict_meanings
        if i < 6:
            write_outputCSV(path,condition,chain,ID,'1wordTraining',meaning,signal,'NA', 'NA','NA','NA','NA','NA',myRole)
            stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
            texty=visual.TextStim(myWin, color='black', units='norm',pos=[0,-0.6],text=signal)
            draw_fixation(myWin)
            stimy.setAutoDraw(True)
            myWin.flip()
            core.wait(1)
            texty.draw()
            myWin.flip()
            myWin.setMouseVisible(False)
            playSound(signal,path)
            myWin.setMouseVisible(True)
            core.wait(2)
            stimy.setAutoDraw(False)
            if event.getKeys(['escape']): 
                myWin.close()
                core.quit()
        else:
            count_minitest_intro+=1
            if count_minitest_intro==1:
                intro_minitest1(myWin,path)
            discrimination_trial(myWin,condition,chain,ID,'1wordTraining',signal,meaning,0,dict_stims,weird,path,myRole)
    for x in range(2):
        for i in range(0):
            count_fullon_training+=1
            if count_fullon_training==1:
                instr_2w_training(myWin,path)
            meaning=random.choice(block_2w)
            block_2w.remove(meaning)
            signal=random.choice(dict_meanings1[meaning])
            dict_meanings1[meaning].remove(signal)
            #print dict_meanings
            if i < 15:
                write_outputCSV(path,condition,chain,ID,'2wordTraining',meaning,signal,'NA', 'NA','NA','NA','NA','NA',myRole)
                stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
                texty=visual.TextStim(myWin, color='black', units='norm',pos=[0,-0.6],text=signal)
                draw_fixation(myWin)
                stimy.setAutoDraw(True)
                myWin.flip()
                core.wait(1)
                texty.draw()
                myWin.flip()
                myWin.setMouseVisible(False)
                playSound(signal,path)
                myWin.setMouseVisible(True)
                core.wait(2)
                stimy.setAutoDraw(False)
                if event.getKeys(['escape']): 
                    myWin.close()
                    core.quit()
            else:
                if 'blue' in meaning: diff_type='adj'
                elif 'two' in meaning: diff_type='num'
                discrimination_trial(myWin,condition,chain,ID,'2wordTraining',signal,meaning,diff_type,dict_stims,weird,path,myRole)
    instr_2w_testing(myWin,path,myRole)
    testing_2wDy(myWin, condition,chain,ID,dict_stims,weird,path,socket,role,myRole)
    instr_fullon_training(myWin,path)
    for block_all in [block_all_1,block_all_2,block_all_3,block_all_4]:
        for i in range(0):
            meaning=random.choice(block_all)
            block_all.remove(meaning)
            signal=random.choice(dict_meanings2[meaning])
            dict_meanings2[meaning].remove(signal)
            #print dict_meanings
            if i < 15:
                write_outputCSV(path,condition,chain,ID,'allTraining',meaning,signal,'NA', 'NA','NA','NA','NA','NA',myRole)
                stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
                texty=visual.TextStim(myWin, color='black', units='norm',pos=[0,-0.6],text=signal)
                draw_fixation(myWin)
                stimy.setAutoDraw(True)
                myWin.flip()
                core.wait(1)
                texty.draw()
                myWin.flip()
                myWin.setMouseVisible(False)
                playSound(signal,path)
                myWin.setMouseVisible(True)
                core.wait(2)
                stimy.setAutoDraw(False)
                if event.getKeys(['escape']): 
                    myWin.close()
                    core.quit()
            else:
                discrimination_trial(myWin,condition,chain,ID,'allTraining',signal,meaning,1,dict_stims,weird,path,myRole)
########################################################################################################################
####################################################TESTING#######################################################
########################################################################################################################

def create_dict_outputSentences():
    meanings=get_meanings()
    forSignals=[[] for i in range(len(meanings))]
    d=dict(zip(meanings,forSignals))
    return d
#important, create dictionary for next generation's input list!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
participantSentences=create_dict_outputSentences()
participantSentences_raw=create_dict_outputSentences()
participantSentences_mixed=create_dict_outputSentences()
participantSentences_raw_mixed=create_dict_outputSentences()

def allow_typing(myWin,condition,chain,ID,meaning,path,number_testing,socket,myRole):
    stopwatch = core.Clock()
    stopwatch.reset()
    #sans = ['Gill Sans MT', 'Arial','Helvetica','Verdana'] #use the first font found on this list
    CapturedResponseString = visual.TextStim(myWin, units='norm',height = 0.1,
                pos=(0, -0.6), text='',
                alignHoriz = 'center',alignVert='center',
                color='DimGray')
    # now we will keep tracking what's happening on the keyboar until the participant hits the return key    
    captured_string = '' #empty for now.. this is a string of zero length that 
    # we will append our key presses to in sequence
    subject_response_finished = 0 # only changes when they hit return

    #check for Esc key / return key presses each frame
    while subject_response_finished == 0:
        for key in event.getKeys():
            #quit at any point
            if key in ['escape']: 
                myWin.close()
                core.quit()            
            #if the participant hits return, save the string so far out 
            #and reset the string to zero length for the next trial
            elif key in ['return']:
                if captured_string != '':
                    rt=stopwatch.getTime()
                    captured_string=captured_string.strip()
                    corrected_string=spellcheckWords(captured_string,condition)
                    write_outputCSV(path,condition,chain,ID,'testing_%s'%number_testing,meaning,'NA',rt, 'NA',captured_string,corrected_string,'NA','NA',myRole)
                    write_sentenceDict(path,condition,chain,ID,meaning,corrected_string,myRole)
                    write_sentenceDict_raw(path,condition,chain,ID,meaning,captured_string,myRole)
                    if myRole=='server':
                        write_sentenceDict_mixed(path,condition,chain,ID,meaning,corrected_string,'mixed')
                        write_sentenceDict_raw_mixed(path,condition,chain,ID,meaning,captured_string,'mixed')
                    info_string=[corrected_string,meaning,captured_string]
                    send_a_message(str(info_string),socket)
                    captured_string = '' #reset to zero length 
                    subject_response_finished = 1 #allows the next trial to start
                else:
                    event.clearEvents(eventType='keyboard')
            #allow the participant to do deletions too , using the 
            # delete key, and show the change they made
            elif key in ['delete','backspace']:
                captured_string = captured_string[:-1]+'_' #delete last character
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]
            #handle spaces
            elif key in ['space']:
                captured_string = captured_string+' _'                
                #show it
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]                
            elif key not in ['space','delete','backsapce','return','scape','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j','k', 'l', 'm', 'n', 'o', 'p','q', 'r', 's','t', 'u', 'v','w','x','y','z']:
                pass #do nothing when some keys are pressed
            #etc ...
            #if any other key is pressed, add it to the string and 
            # show the participant what they typed
            else:                 
                captured_string = captured_string+key+'_'
                #show it
                CapturedResponseString.setColor('black')
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]



def testing_2wDy(myWin, condition,chain,ID,dict_stims,weird,path,socket,role,myRole):
    block2_meanings_1=[('jelpa','blue','one'),]*2+[('mokte','blue','one'),]*3+[('jelpa','plain','two'),]*3+[('mokte','plain','two'),]*2
    block2_meanings_2=[('jelpa','blue','one'),]*3+[('mokte','blue','one'),]*2+[('jelpa','plain','two'),]*2+[('mokte','plain','two'),]*3
    #roles=random.sample(['client','server'],2)
    roles=['client','server']
    if myRole==roles[0]: testing_block=block2_meanings_1
    elif myRole==roles[1]: testing_block=block2_meanings_2
    for i in range(20):
        if role=='send':
            meaning=random.choice(testing_block)
            testing_block.remove(meaning)          
            stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
            start_type=visual.TextStim(myWin, color='DimGray', units='norm',pos=[0,-0.6],text='_')
            draw_fixation(myWin)
            stimy.setAutoDraw(True)
            start_type.draw()
            myWin.flip()
            if event.getKeys(['escape']): 
                myWin.close()
                core.quit()
            allow_typing(myWin,condition,chain,ID,meaning,path,'2w',socket, myRole)
            myWin.flip()
            stimy.setAutoDraw(False)
            wait_feedback(myWin)
            feedback=receive_a_message(True,socket)
            feedback_screen(myWin, feedback,path)
        if role=='recv':
            wait_text(myWin)
            info_string=receive_a_message(True,socket)
            info_string=ast.literal_eval(info_string)
            signal=info_string[2]
            meaning=info_string[1]
            signal_corrected=info_string[0]
            if 'blue' in meaning: diff_type='adj'
            elif 'two' in meaning: diff_type='num'
            discrimination_trialDy(myWin,condition,chain,ID,'matching_2w',signal,meaning,diff_type,dict_stims,weird,path,socket,myRole)
            if myRole=='server':
                write_sentenceDict_mixed(path,condition,chain,ID,meaning,signal_corrected,'mixed')
                write_sentenceDict_raw_mixed(path,condition,chain,ID,meaning,signal,'mixed')
        if role=='send':
            role='recv'
        elif role=='recv':
            role='send'

def testingDy(myWin, condition,chain,ID,dict_stims,weird,path,socket,role,myRole):
    if role=='send':
        role='recv'
    elif role=='recv':
        role='send'
    blockAll_meanings_1=[('mokte','plain','one')]+[('jelpa','blue','one'),]*3+[('mokte','blue','one'),]*2+[('jelpa','plain','two'),]*2+[('mokte','plain','two'),]*3+ [('jelpa','blue','two'),]*7+[('mokte','blue','two'),]*8
    blockAll_meanings_2=[('jelpa','plain','one')]+[('jelpa','blue','one'),]*2+[('mokte','blue','one'),]*3+[('jelpa','plain','two'),]*3+[('mokte','plain','two'),]*2+ [('jelpa','blue','two'),]*8+[('mokte','blue','two'),]*7
    #roles=random.sample(['client','server'],2)
    roles=['client','server']
    if myRole==roles[0]: testing_block=blockAll_meanings_1
    elif myRole==roles[1]: testing_block=blockAll_meanings_2
    for i in range(52):
        if i==37: motivation_last(myWin, path)
        if role=='send':
            meaning=random.choice(testing_block)
            testing_block.remove(meaning)          
            stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
            start_type=visual.TextStim(myWin, color='DimGray', units='norm',pos=[0,-0.6],text='_')
            draw_fixation(myWin)
            stimy.setAutoDraw(True)
            start_type.draw()
            myWin.flip()
            if event.getKeys(['escape']): 
                myWin.close()
                core.quit()
            allow_typing(myWin,condition,chain,ID,meaning,path,'all',socket, myRole)
            myWin.flip()
            stimy.setAutoDraw(False)
            wait_feedback(myWin)
            feedback=receive_a_message(True,socket)
            feedback_screen(myWin, feedback,path)
        if role=='recv':
            wait_text(myWin)
            info_string=receive_a_message(True,socket)
            info_string=ast.literal_eval(info_string)
            signal=info_string[2]
            meaning=info_string[1]
            signal_corrected=info_string[0]
            if meaning in [('mokte','plain','one'),('jelpa','plain','one')]: foils=0
            else: foils=1
            discrimination_trialDy(myWin,condition,chain,ID,'matching_all',signal,meaning,foils,dict_stims,weird,path,socket,myRole)
            if myRole=='server':
                write_sentenceDict_mixed(path,condition,chain,ID,meaning,signal_corrected,'mixed')
                write_sentenceDict_raw_mixed(path,condition,chain,ID,meaning,signal,'mixed')
        if role=='send':
            role='recv'
        elif role=='recv':
            role='send'
########################################################################################################################
####################################################GRAMMATICALITY#######################################################
#########################################################TEST########################################################

def grammaticality_test(myWin,condition,chain,ID,dict_grammaticality,dict_stims,path,ID_minus_one,myRole):
    block_gram=[('jelpa','blue','one'),]*3+[('mokte','blue','one'),]*3+[('jelpa','plain','two'),]*3+[('mokte','plain','two'),]*3+[('jelpa','blue','two'),]*6+[('mokte','blue','two'),]*6
    dict_meanings=read_inputSentences(path,condition,chain,ID_minus_one)
    for i in range(24):         
        meaning=random.choice(block_gram)
        block_gram.remove(meaning)
        signal=random.choice(dict_grammaticality[meaning])
        dict_grammaticality[meaning].remove(signal)
        if sum([signal in i for i in dict_meanings.values()])==0: gramatical='no'
        elif sum([signal in i for i in dict_meanings.values()])!=0:gramatical='yes'
        stimy=visual.ImageStim(myWin, image=dict_stims[meaning], units='norm', size=[1,1],pos=[0,0.2],flipHoriz=False,flipVert=False,autoLog=True)
        question=visual.TextStim(myWin, color='black', units='norm',pos=[0,0.75],wrapWidth=900, text='Is this description correct in Verblog?')
        texty=visual.TextStim(myWin, color='DimGray', units='norm',pos=[0,-0.4],text=signal)
        yes_button=visual.ImageStim(myWin, image=path+'keys/'+'yes_button.jpg', units='norm', size=[0.17,0.21],pos=[-0.6,-0.5],flipHoriz=False,flipVert=False,autoLog=True)
        no_button=visual.ImageStim(myWin, image=path+'keys/'+'no_button.jpg', units='norm', size=[0.17,0.21],pos=[0.6,-0.5],flipHoriz=False,flipVert=False,autoLog=True)
        v_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_V.png', units='norm', size=[0.15,0.15],pos=[-0.6,-0.7],flipHoriz=False,flipVert=False,autoLog=True)
        n_key=visual.ImageStim(myWin, image=path+'keys/'+'computer_key_N.png', units='norm', size=[0.15,0.15],pos=[0.6,-0.7],flipHoriz=False,flipVert=False,autoLog=True)
        play_sound=0
        while True:
            play_sound+=1
            draw_fixation(myWin)
            stimy.setAutoDraw(True)
            myWin.flip()
            core.wait(1)
            texty.setAutoDraw(True)
            myWin.flip()
            if play_sound==1:
                myWin.setMouseVisible(False)
                playSound(signal,path)
                myWin.setMouseVisible(True)
                stopwatch = core.Clock()
                stopwatch.reset()
            question.setAutoDraw(True)
            yes_button.setAutoDraw(True)
            no_button.setAutoDraw(True)
            v_key.setAutoDraw(True)
            n_key.setAutoDraw(True)
            myWin.flip()
            if event.getKeys(['v']):
                rt=stopwatch.getTime()
                write_outputCSV(path,condition,chain,ID,'GrammaticalityTest',meaning,signal,rt, 'NA','NA','NA',gramatical,'yes',myRole)
                stimy.setAutoDraw(False)
                question.setAutoDraw(False)
                yes_button.setAutoDraw(False)
                no_button.setAutoDraw(False)
                v_key.setAutoDraw(False)
                n_key.setAutoDraw(False)
                texty.setAutoDraw(False)
                break
            if event.getKeys(['n']):
                rt=stopwatch.getTime()
                write_outputCSV(path,condition,chain,ID,'GrammaticalityTest',meaning,signal,rt, 'NA','NA','NA',gramatical,'no',myRole)
                stimy.setAutoDraw(False)
                question.setAutoDraw(False)
                yes_button.setAutoDraw(False)
                no_button.setAutoDraw(False)
                v_key.setAutoDraw(False)
                n_key.setAutoDraw(False)
                texty.setAutoDraw(False)
                break
            if event.getKeys(['escape']): 
                myWin.close()
                core.quit()

########################################################################################################################
#####################################################INSTRUCTIONS &###########################################################
#######################################################MESSAGES#######################################################

def pre_experiment_screen(myWin,path):
    instrText = visual.TextStim(myWin,pos=(0,0), units='pix', height=40, wrapWidth=900, color='black',text="""Press the return key to start the experiment.""")
    next_page=visual.ImageStim(myWin, image=path+'keys/return_key.png', units='norm', size=[0.2,0.3],pos=[0.7,-0.6],flipHoriz=False,flipVert=False,autoLog=True)
    #next_tag= visual.TextStim(myWin, color='black', units='norm', pos=[0.45,-0.6], text='Start')
    instrText.draw()
    next_page.draw()
    #next_tag.draw()
    myWin.flip()
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()

def intro_glerma(myWin,path):
    # INSTRUCTIONS -- welcome, intro to noun train
    #display alien & instructions on the screen
    alien = visual.ImageStim(myWin, image='Pics/alienHellowh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""Hello. My name is Glerma. I am here to help you learn the language of my people. We call it: Verblog.\n\nIf you can learn to talk just like me, then your mission will be successful.\n\nWe will start with something easy.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/intro1',path)
    myWin.setMouseVisible(True) #show mouse again
    #INSTRUCTIONS -- intro to noun train
    #display alien & instructions on the screen
    alien = visual.ImageStim(myWin, image='Pics/alienNeutral2wh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""First, I will teach you the names of some simple objects in Verblog.\n\nI will show you a picture, and say its name in my language. You must repeat after me to help you remember it.\n\nPress the return key when you're ready to get started.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/intro2',path)
    myWin.setMouseVisible(True) #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
    #end intro instructions

def intro_minitest1(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienPointwh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""Ok. Now it is time to take a short test on what you have learned.\n\nI will show you four pictures and will say a name in Verblog. You have to select the picture that corresponds to the name in Verblog.\n\n I will let you know the right answer after you have selected a picture. \n\nPress the return key to start the test.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/minitest1',path)
    myWin.setMouseVisible(True)    #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()


def instr_2w_training(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienYaywh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""Congratulations! Great job! You have made it through your first test!\n\nPress the return key to hear about your next task.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/fullon1',path)
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
    alien = visual.ImageStim(myWin, image='Pics/alienNeutralwh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""In this part of your training in Verblog, I will show you pictures as in your previous task, but this time, what I say will be a bit more complex than before.\n\nThe objects you see will look familiar, but they will illustrate some other features of Verblog.\n\nLook at the pictures, listen, and repeat after me to help you remember.""")
    alien.draw(); instrText.draw(); myWin.flip()
    #play instructions
    playSound('alienTalk/fullon2',path)
    myWin.setMouseVisible(True)    #show mouse
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""You will also be tested on what you have learned in Verblog every now and then. The tests will be of the same type as the one you already completed.\n\n Press the return key when you're ready to get started!""")
    alien.draw(); instrText.draw(); myWin.flip()
    #play instructions
    playSound('alienTalk/fullon3',path)
    myWin.setMouseVisible(True)    #show mouse
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()

def instr_2w_testing(myWin,path,myRole):
    text1="""Ok, now it's time for you to speak! \n\nYou and your partner will take turns to communicate with what you have been taught in Verblog. """
    if myRole=='server': 
        text2="""You will be the one to start. You will see a picture and must provide a description in Verblog just like Glerma would. Use the keyboard to type it in. When you've given your answer press the return key to submit it."""
        text3="""Your partner will receive the description and will select the meaning they think corresponds to the description.\n\n If they successfully select the correct meaning, you will see a green screen before you move on to the next trial. \n\n Otherwise, you will see a red screen."""
        text3="""It will then be your partner's turn to speak and your turn to select the described meaning. \n\n This turn-taking procedure will take place over the course of several testing trials.\n\n Press the return jey when you're ready to get started!"""
    elif myRole=='client': 
        text2="""Your partner will be the one to start. \n\nThey will see a picture and will be asked to provide a description in Verblog just like Glerma would."""
        text3="""You will receive the description in written form and will select the meaning you think corresponds to the description.\n\n If you successfully select the correct meaning, you will see a green screen before you move on to the next trial. \n\nOtherwise, you will see a red screen."""
        text4="""It will then be your turn to speak and your partner's turn to select the described meaning. Use the keyboard to type in the descriptions and press the return key to submitt them. \n\n This turn-taking procedure will take place over the course of several testing trials.\n\n Press the return jey when you're ready to get started!"""
    alien = visual.ImageStim(myWin, image='Pics/alienNeutral2wh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text1)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%s_test2w'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    alien = visual.ImageStim(myWin, image='Pics/alienNeutralwh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text2)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%s_test2wBis'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    alien = visual.ImageStim(myWin, image='Pics/alienPointwh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text3)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%s_test2wB'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text4)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%_test2wC'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
    

def instr_fullon_training(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienYaywh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""Great job on your first time speaking Verblog!\n\nPress the return key to hear about your next task.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    playSound('alienTalk/fullon_all1',path)
    myWin.setMouseVisible(True)
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
    alien = visual.ImageStim(myWin, image='Pics/alienNeutral2wh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""This will be the last part of your training in Verblog. \n\n This time I will show you pictures as well, but what I say will sometimes be even more complex than before.\n\n Remember to look at the pictures, listen, and repeat after me. It will really help you master Verblog.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False) 
    playSound('alienTalk/fullon_all2',path)
    myWin.setMouseVisible(True)    #show mouse
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""As in the previous tasks, you will also be tested on what you have learned in Verblog every now and then. \n\nThe tests will be the same type of comprehension tests you are now familiar with.\n\n Press the return key when you're ready to start.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False) 
    playSound('alienTalk/fullon_all3',path)
    myWin.setMouseVisible(True)    #show mouse
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
        

    
def instr_testing(myWin,path,myRole):
    text1="""Well done, you have now completed the training. It is now your turn to speak again."""
    if myRole=='server': 
        text2="""This time you will also take turns with yout partner to describe and select meanings in Verblog. \n\n This time it will be your partner's turn to start. \n\n Press the return key when you're ready to start!"""
    elif myRole=='client': 
        text2="""This time you will also take turns with yout partner to describe and select meanings in Verblog. \n\n This time it will be your turn to start. Use the keyboard to type in the descriptions. When you-ve given your answer press the return jey to submitt it. \n\n Press the return key when you're ready to start!"""
    alien = visual.ImageStim(myWin, image='Pics/alienPointwh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text1)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%s_test'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text=text2)
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/%s_testB'%myRole,path)
    myWin.setMouseVisible(True)    #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
        
def motivation(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienYaywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text="""Great job! \n\nYou're doing great so far.\n\n Press the return key when you are ready to continue speaking Verblog!""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/motivation1',path)
    myWin.setMouseVisible(True)    #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()

def motivation_last(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-175,0), units='pix', height=40, wrapWidth=700, color='black',text="""Great job! \n\n There are only a few more descriptions I would like you give me. This is the last round you will be speaking Verblog.\n\n Press the return key when you are ready to continue!""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    #play instructions
    playSound('alienTalk/motivation2',path)
    myWin.setMouseVisible(True)    #show mouse again
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()

def instr_grammaticality(myWin,path):
    alien = visual.ImageStim(myWin, image='Pics/alienYaywh.jpg', pos=(450,0), units='pix', size=(375,575))
    #write instruction text
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""Fantastic! You're doing great! \n\n Now you're almost done learning Verblog. \n\nPress the return key to hear about your last task.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False)    #hide mouse to prevent seeing pinwheel
    playSound('alienTalk/grammaticality1',path)
    myWin.setMouseVisible(True)
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
    alien = visual.ImageStim(myWin, image='Pics/alienPointwh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""In this last task you will see a familiar picture and will hear a description. \n\n This time you will have to say whether the description is correct in Verblog.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False) 
    playSound('alienTalk/grammaticality2',path)
    myWin.setMouseVisible(True)    #show mouse
    alien = visual.ImageStim(myWin, image='Pics/alienReadywh.jpg', pos=(450,0), units='pix', size=(375,575))
    instrText = visual.TextStim(myWin,pos=(-100,0), units='pix', height=40, wrapWidth=700, color='black',text="""If you have heard the description for the picture before, you will have to press the V key to verify it. \n\n If you have not heard it before in Verblog, you will have to press the N key. \n\n Please press the return key to start this last task.""")
    alien.draw(); instrText.draw(); myWin.flip()
    myWin.setMouseVisible(False) 
    playSound('alienTalk/grammaticality3',path)
    myWin.setMouseVisible(True)    #show mouse
    #wait for space bar press to move on to next trial
    while True:
        keys = event.getKeys()
        if 'return' in keys: break
        if 'escape' in keys: core.quit()
        
def final_message(myWin,path,condition):
    planet = visual.ImageStim(myWin, image='Pics/PlanetAlienYay.jpg', units='pix', size=(1280,800))#1680,1050
    planet.draw(); myWin.flip()
    #playSound('alienTalk/bye%s'%condition,path)
    playSound('alienTalk/bye',path)
########################################################################################################################
####################################################DATA HANDLING###########################################################
########################################################################################################################

def eval_data_dict(d):
    dm=[]
    ds=[]
    for i in d: 
        dm.append(ast.literal_eval(i))
        ds.append(ast.literal_eval(d[i]))
    return OrderedDict(zip(dm,ds))    
 
def read_inputSentences(path,condition,chain,ID_minus_one):
    file=path+'data/'+'%s%s%sD_sentencesdict.csv'%(condition,chain,ID_minus_one)
    with open(file) as csvfile:
	    reader = csv.DictReader(csvfile)
	    for row in reader:
	        d=row
	    eval_d=eval_data_dict(d)
    return eval_d

def create_outputSentences(path,condition,chain,ID,myRole):
    file=path+'data/'+'%s%s%sD_%s_sentencesdict.csv'%(condition,chain,ID,myRole)
    if os.path.isfile(file)==False: 
        f=open(file,'wb')
        f.close()
    else:
        print 'You already ran that chain!'
        sys.exit()
    
def write_sentenceDict(path, condition,chain,ID,meaning,signal,myRole):
    global participantSentences
    if meaning in [('jelpa', 'plain', 'one'),('mokte', 'plain', 'one')]:
        for i in range(5): participantSentences[meaning].append(signal)
    else:
        participantSentences[meaning].append(signal)
    write_outputSentences(path,condition,chain,ID,participantSentences,myRole)
    
def write_sentenceDict_mixed(path, condition,chain,ID,meaning,signal,myRole):
    global participantSentences_mixed
    if meaning in [('jelpa', 'plain', 'one'),('mokte', 'plain', 'one')]:
        for i in range(5): participantSentences_mixed[meaning].append(signal)
    else:
        participantSentences_mixed[meaning].append(signal)
    write_outputSentences(path,condition,chain,ID,participantSentences_mixed,myRole)
    
def write_outputSentences(path,condition,chain,ID,dict_responses,myRole):
    file=path+'data/'+'%s%s%sD_%s_sentencesdict.csv'%(condition,chain,ID,myRole)
    my_dict=dict_responses
    with open(file,'wb') as f: 
        w = csv.DictWriter(f, my_dict.keys())
        w.writeheader()
        w.writerow(my_dict)
    f.close()
    
def create_outputSentences_raw(path,condition,chain,ID,myRole):
    file=path+'data/'+'%s%s%sD_%s_sentencesdict_raw.csv'%(condition,chain,ID,myRole)
    f=open(file,'wb')
    f.close()
    
def write_outputSentences_raw(path,condition,chain,ID,dict_responses,myRole):
    file=path+'data/'+'%s%s%sD_%s_sentencesdict_raw.csv'%(condition,chain,ID,myRole)
    my_dict=dict_responses
    with open(file,'wb') as f: 
        w = csv.DictWriter(f, my_dict.keys())
        w.writeheader()
        w.writerow(my_dict)
    f.close()

def write_sentenceDict_raw(path, condition,chain,ID,meaning,signal,myRole):
    global participantSentences_raw
    if meaning in [('jelpa', 'plain', 'one'),('mokte', 'plain', 'one')]:
        for i in range(5): participantSentences_raw[meaning].append(signal)
    else:
        participantSentences_raw[meaning].append(signal)
    write_outputSentences_raw(path,condition,chain,ID,participantSentences_raw,myRole)
    
def write_sentenceDict_raw_mixed(path, condition,chain,ID,meaning,signal,myRole):
    global participantSentences_raw_mixed
    if meaning in [('jelpa', 'plain', 'one'),('mokte', 'plain', 'one')]:
        for i in range(5): participantSentences_raw_mixed[meaning].append(signal)
    else:
        participantSentences_raw_mixed[meaning].append(signal)
    write_outputSentences_raw(path,condition,chain,ID,participantSentences_raw_mixed,myRole)
    
def set_outputCSV(path,condition,chain,ID,myRole):
    file=path+'data/%s%s%sD_%s_responses.csv'%(condition,chain,ID,myRole)
    with open(file,'wb') as f:
        w = csv.writer(f)
        w.writerow(['condition','chain','gen','phase','meaning','inputSentence','RT','meaningSelection','outputSentence','correctedOutput', 'grammatical','grammaticalityJudgment','date&time','pair'])
    f.close()
    
def write_outputCSV(path,condition,chain,ID,phase,meaning,inputSentence,RT, meaningSelection,outputSentence,correctedOutput,grammatical,judgement,myRole):
    file=path+'data/%s%s%sD_%s_responses.csv'%(condition,chain,ID,myRole)
    if isinstance(RT,float): RT=round(RT,2)
    #remember to open file with a and not w
    with open(file, 'a') as f:
        w=csv.writer(f)
        w.writerow([condition,chain,ID,phase,meaning,inputSentence,RT,meaningSelection,outputSentence,correctedOutput,grammatical,judgement,time.asctime(),myRole])
    f.close()

########################################################################################################################
####################################################OTHER FUNCTIONS###########################################################
########################################################################################################################

def all_indices(value, qlist):
    indices = []
    idx = -1
    while True:
        try:
            idx = qlist.index(value, idx+1)
            indices.append(idx)
        except ValueError:
            break
    return indices



    

