from psychopy import core, visual, event, gui
from psychopy import prefs
prefs.general['audioLib'] = ['pygame']
from psychopy import sound
from EvoVarDy import *
import random
import numpy as np
from PIL import Image
import pickle
import itertools
import pyglet
import pygame
import webbrowser
from socket import *

#designate a server
#input other machines ip address
#find your own ip address
SERVER=False
OTHER_IP_ADDR='192.168.0.12'#'127.0.0.1'
MY_IP_ADDR= gethostbyname(gethostname())


#get participant's info
info = {"Chain":'',"Participant's ID":'',"Condition":'', "Role":''}
infoDlg = gui.DlgFromDict(dictionary=info, title='EvoVarDy', fixed=['ExpVersion3'])
if infoDlg.OK:
    print info        
else: print 'User Cancelled'


ID=info["Participant's ID"]
chain=int(info["Chain"])
condition=info["Condition"]
myRole=info["Role"]
ID_minus_one= int(float(ID))-1
ID_iterated_string=str(ID_minus_one)

path='/Users/pplsuser/Desktop/EvoVarDy/'


create_outputSentences(path,condition,chain,ID,myRole)
create_outputSentences_raw(path,condition,chain,ID,myRole)
set_outputCSV(path,condition,chain,ID,myRole)

dict_stims=dict_stims(path)
dict_all=dict_stims_discrimination(path)
dict_meanings1=read_inputSentences(path,condition,chain,ID_minus_one)
dict_meanings2=read_inputSentences(path,condition,chain,ID_minus_one)
double_dict2(dict_meanings2)
dict_grammaticality=get_dict_grammaticality(condition)

myWin = visual.Window((1080,600),color='white', allowGUI=True,monitor='testMonitor', units ='deg', fullscr=False)#1680,1050


'''#####################  MACHINE PAIRING ####################'''

waiting_connection(myWin)

#if server, create a socket and bind it to own ip address
#if not server, create socket and connect it to servers ip address
if SERVER:
    s=socket(AF_INET,SOCK_STREAM)
    s.bind((MY_IP_ADDR,7213))
    s.listen(1)
    c, a=s.accept()
    SOCKET=c
else:
    s=socket(AF_INET,SOCK_STREAM)
    s.connect((OTHER_IP_ADDR,7213))
    SOCKET=s
    
#sends a message to other machine
def send_message(message):
    SOCKET.send(message)

#listens for message from other machine, whether blocked or unblocked
def receive_message(blocked):
    SOCKET.setblocking(blocked)
    try:
        return SOCKET.recv(1024)
    except:
        return ''

#myWin.setMouseVisible(False)

if SERVER:
    role='send'
else:
    role='recv'


'''##################### EXPERIMENT BEGINS ####################'''

pre_experiment_screen(myWin,path)
intro_glerma(myWin,path)
trainingDy(myWin,condition,chain,ID,dict_meanings1, dict_meanings2,dict_stims,dict_all,path,SOCKET,role,myRole)
instr_testing(myWin,path)
testingDy(myWin,condition,chain,ID,dict_stims,dict_all,path,SOCKET,role,myRole)
instr_grammaticality(myWin,path)
grammaticality_test(myWin,condition,chain,ID,dict_grammaticality,dict_stims,path,ID_minus_one,myRole)
final_message(myWin,path,condition)
SOCKET.close()
if condition=='m': browser=webbrowser.open('https://docs.google.com/forms/d/e/1FAIpQLSd6n87fhUoBroav80-vFlUw4OVUdbthkkwAMSz3ZfSbiFOaCQ/viewform')
if condition=='ss': browser=webbrowser.open('https://docs.google.com/forms/d/e/1FAIpQLSfiXvke9_IIyThE2WEVgsI0wPFqRnsAkqiu8fKl_mflb32TYg/viewform')