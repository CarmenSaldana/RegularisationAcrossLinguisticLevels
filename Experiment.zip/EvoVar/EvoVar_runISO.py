from psychopy import core, visual, event, gui
from psychopy import prefs
prefs.general['audioLib'] = ['pygame']
from psychopy import sound
from EvoVar2 import *
import random
import numpy as np
from PIL import Image
import pickle
import itertools
import pyglet
import pygame
import webbrowser

#get participant's info
info = {"Chain":'',"Participant's ID":'',"Condition":''}
infoDlg = gui.DlgFromDict(dictionary=info, title='EvoVar', fixed=['ExpVersion1'])
if infoDlg.OK:
    print info        
else: print 'User Cancelled'


ID=info["Participant's ID"]
chain=int(info["Chain"])
condition=info["Condition"]
ID_minus_one= int(float(ID))-1
ID_iterated_string=str(ID_minus_one)

path='/Users/pplsuser/Desktop/EvoVar/'

create_outputSentences(path,condition,chain,ID)
create_outputSentences_raw(path,condition,chain,ID)
set_outputCSV(path,condition,chain,ID)

dict_stims=dict_stims(path)
dict_all=dict_stims_discrimination(path)
dict_meanings1=read_inputSentences(path,condition,chain,ID_minus_one)
dict_meanings2=read_inputSentences(path,condition,chain,ID_minus_one)
double_dict2(dict_meanings2)
dict_grammaticality=get_dict_grammaticality(condition)

myWin = visual.Window((1280,800),color='white', allowGUI=True,monitor='testMonitor', units ='deg', fullscr=True)#1680,1050

pre_experiment_screen(myWin,path)
intro_glerma(myWin,path)
training(myWin,condition,chain,ID,dict_meanings1, dict_meanings2,dict_stims,dict_all,path)
instr_testing(myWin,path)
testing(myWin,condition,chain,ID,dict_stims,path)
instr_grammaticality(myWin,path)
grammaticality_test(myWin,condition,chain,ID,dict_grammaticality,dict_stims,path,ID_minus_one)
final_message(myWin,path,condition)
if condition=='s': browser=webbrowser.open('https://docs.google.com/forms/d/1dyf8yRgODjXJyCDQdtlIL-AyfNU10XOWn3fRR4XXaNU/viewform')
if condition=='m': browser=webbrowser.open('https://docs.google.com/forms/d/1p8_LmmIA5sKtH8J3EJsTauKrLf4LNvW16NRKDCx_RYU/viewform')
if condition=='ss': browser=webbrowser.open('https://docs.google.com/forms/d/e/1FAIpQLScRy-u_36hWC1iZtVWl06MM-sRVtV0iJwkfQswmiHaxCb1gZA/viewform')